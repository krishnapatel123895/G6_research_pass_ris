import numpy as np
import pytest
from config import SimulationConfig
from channel_model import generate_channels
from model import (effective_channels, make_normalized_precoders, make_ris_vector,
                   paper_gmi_rates, radar_sinr_paper, active_ris_power)
from radar_model import generate_radar_channels, radar_effective_channel


def test_radar_channel_shapes_and_finiteness():
    cfg=SimulationConfig(); Hm,Hn=generate_radar_channels(cfg)
    assert Hm.shape==(cfg.M,cfg.M)
    assert Hn.shape==(cfg.M,cfg.N)
    assert np.isfinite(Hm).all() and np.isfinite(Hn).all()


def test_radar_effective_channel_shape():
    cfg=SimulationConfig(); rng=np.random.default_rng(123)
    ch=generate_channels(cfg,rng); Hm,Hn=generate_radar_channels(cfg)
    phi=make_ris_vector(cfg,rng,amplitude=.2)
    Hr=radar_effective_channel(Hm,Hn,ch['H_br'],phi)
    assert Hr.shape==(cfg.M,cfg.M)


def test_paper_gmi_rates_are_finite():
    cfg=SimulationConfig(); rng=np.random.default_rng(124)
    ch=generate_channels(cfg,rng); phi=make_ris_vector(cfg,rng,amplitude=.2)
    P=make_normalized_precoders(cfg,rng)
    heff=effective_channels(ch['h_bk'],ch['h_rk'],ch['H_br'],phi)
    r=paper_gmi_rates(heff,ch['h_rk'],ch['H_br'],phi,P,cfg.ris_noise_w,cfg.receiver_noise_w,cfg.csi_error_w)
    assert np.isfinite(r['sum_rate']) and r['sum_rate']>=0
    assert r['common_rate_each_user'].shape==(cfg.K,)
    assert r['private_rates'].shape==(cfg.K,)


def test_radar_sinr_is_nonnegative_and_finite():
    cfg=SimulationConfig(); rng=np.random.default_rng(125)
    ch=generate_channels(cfg,rng); phi=make_ris_vector(cfg,rng,amplitude=.2)
    P=make_normalized_precoders(cfg,rng); Hm,Hn=generate_radar_channels(cfg)
    Hr=radar_effective_channel(Hm,Hn,ch['H_br'],phi)
    gamma=radar_sinr_paper(Hr,Hn,phi,ch['H_br'],P,cfg.ris_noise_w,cfg.radar_noise_w,cfg.csi_error_w)
    assert np.isfinite(gamma) and gamma>=0
    assert active_ris_power(ch['H_br'],P,phi,cfg.ris_noise_w)>=0
