import pytest
cp = pytest.importorskip('cvxpy')

def test_cvxpy_basic_solver_if_available():
    x=cp.Variable()
    problem=cp.Problem(cp.Minimize(cp.square(x-2)), [x>=0])
    # Use a non-MOSEK installed solver for a portable unit test, if available.
    installed=set(cp.installed_solvers())
    candidates=[s for s in ('CLARABEL','OSQP','SCS','SCIPY') if s in installed]
    if not candidates:
        pytest.skip('No suitable CVXPY solver installed in this environment.')
    problem.solve(solver=candidates[0])
    assert problem.status in ('optimal','optimal_inaccurate')
    assert x.value == pytest.approx(2, abs=1e-3)
