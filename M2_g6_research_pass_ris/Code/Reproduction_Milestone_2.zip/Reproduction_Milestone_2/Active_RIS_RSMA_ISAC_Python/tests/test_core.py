import numpy as np
import pytest
from config import SimulationConfig, dbm_to_watt, watt_to_dbm
from channel_model import path_loss_db, path_gain, steering_vector, generate_channels
from model import effective_channels, active_ris_power, transmit_power, rsma_rates, make_normalized_precoders, make_ris_vector

def test_dbm_conversion_roundtrip():
    assert dbm_to_watt(30) == pytest.approx(1.0)
    assert dbm_to_watt(0) == pytest.approx(1e-3)
    assert watt_to_dbm(dbm_to_watt(-80)) == pytest.approx(-80)

def test_path_loss_equations():
    assert path_loss_db(10, 'indirect') == pytest.approx(57.6)
    assert path_loss_db(10, 'direct') == pytest.approx(69.3)
    assert path_gain(10, 'direct') > 0
    with pytest.raises(ValueError): path_loss_db(0, 'direct')

def test_steering_vector_norm_and_shape():
    a=steering_vector(8, 0.3)
    assert a.shape == (8,)
    assert np.linalg.norm(a) == pytest.approx(1.0)

def test_channel_dimensions_and_finiteness():
    cfg=SimulationConfig(); ch=generate_channels(cfg, np.random.default_rng(123))
    assert ch['h_bk'].shape == (cfg.K,cfg.M)
    assert ch['H_br'].shape == (cfg.N,cfg.M)
    assert ch['h_rk'].shape == (cfg.K,cfg.N)
    assert all(np.isfinite(x).all() for x in ch.values())

def test_effective_channel_dimensions():
    cfg=SimulationConfig(); rng=np.random.default_rng(1); ch=generate_channels(cfg,rng)
    phi=make_ris_vector(cfg,rng)
    heff=effective_channels(ch['h_bk'],ch['h_rk'],ch['H_br'],phi)
    assert heff.shape == (cfg.K,cfg.M)
    with pytest.raises(ValueError): effective_channels(ch['h_bk'],ch['h_rk'],ch['H_br'],phi[:-1])

def test_power_constraints_accounting_is_nonnegative():
    cfg=SimulationConfig(); rng=np.random.default_rng(2); ch=generate_channels(cfg,rng)
    P=make_normalized_precoders(cfg,rng); phi=make_ris_vector(cfg,rng,amplitude=0.8)
    assert transmit_power(P) == pytest.approx(cfg.bs_power_w)
    pr=active_ris_power(ch['H_br'],P,phi,cfg.ris_noise_w)
    assert pr >= 0 and np.isfinite(pr)

def test_rsma_rates_finite_and_nonnegative():
    cfg=SimulationConfig(); rng=np.random.default_rng(3); ch=generate_channels(cfg,rng)
    phi=make_ris_vector(cfg,rng,amplitude=0.5); P=make_normalized_precoders(cfg,rng)
    heff=effective_channels(ch['h_bk'],ch['h_rk'],ch['H_br'],phi)
    r=rsma_rates(heff,ch['h_rk'],phi,P,cfg.ris_noise_w,cfg.receiver_noise_w,cfg.csi_error_w)
    assert r['common_rates' if 'common_rates' in r else 'common_rate_each_user'].shape == (cfg.K,)
    assert np.isfinite(r['sum_rate']) and r['sum_rate'] >= 0
    assert np.all(r['private_rates'] >= 0)

def test_ris_amplitude_clipping():
    cfg=SimulationConfig(); phi=make_ris_vector(cfg,np.random.default_rng(4),amplitude=cfg.vmax+100)
    assert np.max(np.abs(phi)) <= cfg.vmax + 1e-12

def test_active_ris_power_matches_explicit_diagonal_formula():
    cfg=SimulationConfig(); rng=np.random.default_rng(77); ch=generate_channels(cfg,rng)
    P=make_normalized_precoders(cfg,rng); phi=make_ris_vector(cfg,rng,amplitude=0.25)
    actual=active_ris_power(ch['H_br'],P,phi,cfg.ris_noise_w)
    explicit=0.0
    Phi=np.diag(phi)
    for j in range(P.shape[1]):
        explicit += np.linalg.norm(Phi @ ch['H_br'] @ P[:,j])**2
    explicit += cfg.ris_noise_w*np.linalg.norm(Phi,'fro')**2
    assert actual == pytest.approx(explicit, rel=1e-12, abs=1e-18)

def test_common_rate_is_bottleneck_user_rate():
    cfg=SimulationConfig(); rng=np.random.default_rng(88); ch=generate_channels(cfg,rng)
    phi=make_ris_vector(cfg,rng,amplitude=0.3); P=make_normalized_precoders(cfg,rng)
    heff=effective_channels(ch['h_bk'],ch['h_rk'],ch['H_br'],phi)
    rates=rsma_rates(heff,ch['h_rk'],phi,P,cfg.ris_noise_w,cfg.receiver_noise_w,cfg.csi_error_w)
    assert rates['common_rate'] == pytest.approx(np.min(rates['common_rate_each_user']))
