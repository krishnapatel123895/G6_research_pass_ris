"""AO-based parameter sweeps for the paper's Fig. 4/6/7/9 study variables.

Examples from project root:
  python experiments/run_parameter_sweep.py --parameter users --values 2 3 4 --solver MOSEK
  python experiments/run_parameter_sweep.py --parameter ris_elements --values 16 25 36 49 --solver MOSEK
  python experiments/run_parameter_sweep.py --parameter radar_threshold --values 1 2 3 4 --solver MOSEK
  python experiments/run_parameter_sweep.py --parameter bs_ris_distance --values 10 20 25 30 40 --solver MOSEK

Every point is a separate AO run. These are figure-reproduction attempts; exact
paper geometries/Monte-Carlo settings not stated in the article remain assumptions.
"""
import argparse, json
from dataclasses import replace
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from config import SimulationConfig
from optimization.ao import run_ao

PARAMS = {
    'users': ('K', 'Number of users', lambda c,v: replace(c,K=int(v))),
    'ris_elements': ('N', 'Number of RIS elements', lambda c,v: replace(c,N=int(v))),
    'radar_threshold': ('gamma_radar_threshold', 'Radar SINR threshold', lambda c,v: replace(c,gamma_radar_threshold=float(v))),
    'bs_ris_distance': ('bs_ris_distance_m', 'BS–RIS distance (m)', lambda c,v: replace(c,bs_ris_distance_m=float(v))),
    'csi_error_dbm': ('csi_error_dbm', 'CSI-error variance setting (dBm)', lambda c,v: replace(c,csi_error_dbm=float(v))),
    'antennas': ('M', 'Number of BS antennas', lambda c,v: replace(c,M=int(v))),
}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--parameter',choices=PARAMS,required=True)
    ap.add_argument('--values',type=float,nargs='+',required=True)
    ap.add_argument('--solver',default='MOSEK')
    ap.add_argument('--output',default=None)
    args=ap.parse_args()
    _, xlabel, builder=PARAMS[args.parameter]
    root=Path(args.output or f'results/sweep_{args.parameter}'); root.mkdir(parents=True,exist_ok=True)
    base=SimulationConfig(); rows=[]
    for idx,val in enumerate(args.values):
        cfg=builder(base,val)
        # Validate each changed configuration before running the solver.
        cfg.validate()
        dest=root/f'point_{idx+1}_{val:g}'
        res=run_ao(cfg,args.solver,str(dest))
        s=json.loads((dest/'ao_summary.json').read_text(encoding='utf-8'))
        radar=float(s['final_radar_sinr'])
        rows.append({'parameter':args.parameter,'value':val,'sum_rate_bps_hz':float(s['final_sum_rate_bps_hz']),
                     'radar_sinr':radar,'radar_rate_bps_hz':float(np.log2(1+max(radar,0))),
                     'feasible':bool(s.get('feasible',False)),'status':s['status'],
                     'bs_power_w':float(s['final_bs_power_w']),'ris_power_w':float(s['final_ris_power_w'])})
        print(rows[-1])
    summary={'status':'AO_parameter_sweep_attempt','parameter':args.parameter,
             'note':'Inspect feasibility and compare with paper. This does not include all access/RIS baselines in every paper figure.',
             'results':rows}
    (root/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    x=[r['value'] for r in rows]; y=[r['sum_rate_bps_hz'] for r in rows]
    fig,ax=plt.subplots(figsize=(7,4.5)); ax.plot(x,y,marker='o')
    ax.set_xlabel(xlabel); ax.set_ylabel('Sum rate (bit/s/Hz)')
    ax.set_title(f'AO-based parameter sweep: {args.parameter}'); ax.grid(True,alpha=.3)
    fig.tight_layout(); fig.savefig(root/'sum_rate_sweep.png',dpi=200); plt.close(fig)
    if args.parameter=='radar_threshold':
        fig,ax=plt.subplots(figsize=(7,4.5)); ax.plot(x,[r['radar_rate_bps_hz'] for r in rows],marker='s')
        ax.set_xlabel(xlabel); ax.set_ylabel('Radar GMI rate (bit/s/Hz)')
        ax.set_title('Communication/radar trade-off (AO sweep)'); ax.grid(True,alpha=.3)
        fig.tight_layout(); fig.savefig(root/'radar_rate_sweep.png',dpi=200); plt.close(fig)

if __name__=='__main__': main()
