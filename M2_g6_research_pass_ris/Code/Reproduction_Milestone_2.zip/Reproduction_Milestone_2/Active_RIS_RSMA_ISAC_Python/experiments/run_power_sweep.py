"""AO-based BS transmit-power sweep (intended Figure 3 reproduction attempt).

Run from project root: python experiments/run_power_sweep.py --solver MOSEK
This is computationally expensive because every point runs AO optimization.
"""
import argparse, json
from dataclasses import replace
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from config import SimulationConfig
from optimization.ao import run_ao


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--solver',default='MOSEK')
    parser.add_argument('--powers',type=float,nargs='+',default=[15,20,25,30,35])
    parser.add_argument('--output',default='results/figure3_power_sweep')
    parser.add_argument('--trials',type=int,default=1,help='Independent channel realizations per power point; default 1 for runtime.')
    args=parser.parse_args()
    root=Path(args.output); root.mkdir(parents=True,exist_ok=True)
    cfg0=SimulationConfig(); rows=[]
    for power in args.powers:
        rates=[]; radar=[]; statuses=[]
        for trial in range(args.trials):
            cfg=replace(cfg0,bs_power_dbm=float(power),seed=cfg0.seed+10000*int(power)+trial)
            dest=root/f'power_{power:g}_trial_{trial+1}'
            res=run_ao(cfg,args.solver,str(dest))
            summ=json.loads((dest/'ao_summary.json').read_text())
            rates.append(float(summ['final_sum_rate_bps_hz']))
            radar.append(float(summ['final_radar_sinr']))
            statuses.append(summ['status'])
        rows.append({'bs_power_dbm':power,'mean_sum_rate_bps_hz':sum(rates)/len(rates),
                     'std_sum_rate_bps_hz':float(__import__('numpy').std(rates,ddof=1)) if len(rates)>1 else 0.0,
                     'mean_radar_sinr':sum(radar)/len(radar),'statuses':statuses,'trial_rates':rates})
        print(rows[-1])
    summary={'status':'ao_power_sweep','scope':'AO optimizer with documented assumptions; compare against paper before claiming reproduction',
             'trials_per_point':args.trials,'results':rows}
    (root/'figure3_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    x=[r['bs_power_dbm'] for r in rows]; y=[r['mean_sum_rate_bps_hz'] for r in rows]; e=[r['std_sum_rate_bps_hz'] for r in rows]
    fig,ax=plt.subplots(figsize=(7,4.5)); ax.errorbar(x,y,yerr=e,marker='o',capsize=3)
    ax.set_xlabel('BS transmit power budget (dBm)'); ax.set_ylabel('Sum rate (bit/s/Hz)')
    ax.set_title('AO-based transmit-power sweep (Figure 3 reproduction attempt)'); ax.grid(True,alpha=.3)
    fig.tight_layout(); fig.savefig(root/'figure3_power_sweep.png',dpi=200); plt.close(fig)

if __name__=='__main__': main()
