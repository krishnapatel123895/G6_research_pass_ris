"""Plot a BS transmit beampattern proxy from an AO solution.

This computes a(theta)^H P P^H a(theta). The article's exact Fig. 10 sensing
beampattern normalization/target parameters are not fully specified, so this
is labelled a beampattern proxy until checked against the paper's definition.
"""
import argparse
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from channel_model import steering_vector


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--solution',default='results/paper_reproduction/ao_solution.npz')
    ap.add_argument('--output',default='results/paper_reproduction/beampattern_proxy.png')
    ap.add_argument('--spacing',type=float,default=.5)
    args=ap.parse_args()
    data=np.load(args.solution)
    P=data['precoders']; R=P@P.conj().T; M=P.shape[0]
    angles=np.linspace(-np.pi/2,np.pi/2,721)
    gain=np.array([np.real(np.conjugate(steering_vector(M,a,args.spacing)) @ R @ steering_vector(M,a,args.spacing)) for a in angles])
    gain=np.maximum(gain,1e-30); gain_db=10*np.log10(gain/np.max(gain))
    out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True)
    fig,ax=plt.subplots(figsize=(7,4.5)); ax.plot(np.rad2deg(angles),gain_db)
    ax.set_xlabel('Angle (degrees)'); ax.set_ylabel('Normalized transmit gain (dB)')
    ax.set_title('BS transmit beampattern proxy — verify against Fig. 10 definition')
    ax.set_ylim(-50,0); ax.grid(True,alpha=.3); fig.tight_layout(); fig.savefig(out,dpi=200); plt.close(fig)
    print(f'Saved {out}')

if __name__=='__main__': main()
