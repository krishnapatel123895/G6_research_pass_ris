# Active RIS–RSMA–ISAC (Python) — reproducible research starter

This project uses **Python + NumPy + SciPy + CVXPY + MOSEK** (no MATLAB required).
It is organized to reproduce and extend *Beamforming Design for Enhanced Sum Rate in Active RIS-RSMA-Assisted ISAC Systems Under Imperfect CSIT/CSIR* (Parihar et al., IEEE TVT, 2026).

## Scientific scope note
This repository now includes an implementation attempt for the paper's BS SDR/CCCP block, RIS auxiliary-variable/DC/SCA block, and outer AO loop. It is **not yet validated as an exact reproduction**: the paper leaves target geometry/reflection settings and some error-covariance details ambiguous, and the published figures must be compared before claiming successful reproduction. See `REPRODUCTION_NOTES.md` for equation mapping and explicit assumptions. The random baseline remains diagnostic only.

## 1. Setup in VS Code (Windows)
Open this folder in VS Code. In its terminal run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use `\.venv\Scripts\python.exe` directly for commands. If CVXPY and MOSEK already work in your existing environment, you can skip the install and select that same Python interpreter in VS Code.

## 2. Verify environment

```powershell
python -m pytest -q
python verify_environment.py
```

MOSEK requires a valid license. The smoke test checks the solver only when MOSEK is installed and licensed; otherwise it prints a useful message and exits without confusing a license problem with a model failure.

## 3. Run the diagnostic baseline

```powershell
python main.py
```

It writes `results/baseline_summary.json` and `results/baseline_sweep.png`. This is a reproducible baseline/diagnostic run using fixed, normalized precoders and randomized channel realizations, **not the paper's AO optimum**.

## 4. Run the paper-based AO implementation

```powershell
python reproduce_paper.py --solver MOSEK
```

This attempts one AO scenario, writing `results/paper_reproduction/ao_summary.json`, `ao_solution.npz`, and `ao_convergence.png`. It may be computationally expensive or report infeasibility due to nonconvex local optimization and unspecified paper parameters. Review all feasibility diagnostics before interpreting results.

The AO-based transmit-power sweep is available with `python experiments/run_power_sweep.py --solver MOSEK`. Parameter sweeps are available through `python experiments/run_parameter_sweep.py --parameter users --values 2 3 4 --solver MOSEK` (other options: `ris_elements`, `radar_threshold`, `bs_ris_distance`, `csi_error_dbm`, `antennas`). The beampattern proxy is `python experiments/plot_beampattern.py` after a successful AO run. These runs can be computationally expensive, and some paper multi-scheme baselines remain unfinished.

## 5. Paper parameters used as defaults

| Parameter | Default | Source |
|---|---:|---|
| BS antennas M | 3 | Paper Table I / Section IV |
| Users K | 3 | Paper Table I / Section IV |
| RIS elements N | 36 | Paper Table I / Section IV |
| BS power budget | 35 dBm | Paper Table I / Section IV |
| Active RIS power budget | 10 dBm | Paper Table I / Section IV |
| Max element amplitude | 6 | Paper Table I / Section IV |
| Receiver and RIS thermal noise | -80 dBm | Paper Table I / Section IV |
| CSI error power | -60 dBm | Paper Table I / Section IV |
| Rician K-factor | 3 | Paper Table I / Section IV |
| Indirect path loss | 35.6 + 22 log10(d) dB | Paper Eq. (102) |
| Direct path loss | 32.6 + 36.7 log10(d) dB | Paper Eq. (103) |
| Convergence tolerance | 1e-3 | Paper Section IV |

Paper unspecified parameters (carrier wavelength, precise geometries/angles, random seeds/Monte Carlo count, and some implementation details) are exposed as assumptions in `config.py`; do not report them as paper-provided values.

## 6. Structure

- `config.py`: parameters and dBm/W conversion
- `channel_model.py`: Rayleigh/Rician channels and steering vectors
- `model.py`: effective channels, active-RIS power, imperfect-CSI RSMA rates, radar SINR proxy
- `baseline.py`: reproducible diagnostic sweep (not optimized AO)
- `optimization/ao.py`: BS SDR/CCCP, RIS DC/SCA and outer AO implementation attempt
- `optimization/`: solver smoke test and optimizer notes
- `radar_model.py`: radar echo steering/channel model with documented assumptions
- `reproduce_paper.py`: single AO run and convergence plot
- `experiments/run_power_sweep.py`: AO-based BS power sweep
- `REPRODUCTION_NOTES.md`: equation-to-code map, assumptions and validation checklist
- `tests/`: numerical, shape, power, and rate checks
- `simulations/`: run entry points
- `results/`: generated outputs

## 7. Research integrity checklist

Before calling this an exact reproduction, implement and validate both paper optimization blocks, add the radar channel/error covariance as defined in the paper, use the paper's exact simulation geometry, and compare every figure against the published plots. The paper's model includes common, private, and radar streams: `x = p_c s_c + sum_k p_k s_k + p_r s_r`. This code keeps all three streams in the model.
