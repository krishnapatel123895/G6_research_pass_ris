from baseline import run_sweep

if __name__ == "__main__":
    run_sweep()
