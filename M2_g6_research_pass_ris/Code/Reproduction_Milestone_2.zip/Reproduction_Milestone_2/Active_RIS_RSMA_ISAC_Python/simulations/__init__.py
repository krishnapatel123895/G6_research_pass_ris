"""Simulation entry points."""
