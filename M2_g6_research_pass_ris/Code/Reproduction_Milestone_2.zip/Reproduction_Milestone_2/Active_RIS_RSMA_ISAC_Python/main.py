from baseline import run_sweep
import json

if __name__ == "__main__":
    result = run_sweep()
    print(json.dumps(result, indent=2))
    print("\nCreated results/baseline_summary.json and results/baseline_sweep.png")
