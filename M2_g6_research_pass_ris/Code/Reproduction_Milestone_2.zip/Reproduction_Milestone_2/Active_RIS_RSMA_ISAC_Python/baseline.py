"""Reproducible diagnostic sweep; not a substitute for the paper's AO optimizer."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from config import SimulationConfig, dbm_to_watt
from channel_model import generate_channels
from model import effective_channels, make_normalized_precoders, make_ris_vector, rsma_rates, active_ris_power

def run_sweep(output_dir='results', power_points_dbm=(15,20,25,30,35), trials=10):
    cfg = SimulationConfig()
    cfg.validate()
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    mean_rates, std_rates = [], []
    for pt_dbm in power_points_dbm:
        samples=[]
        for t in range(trials):
            rng=np.random.default_rng(cfg.seed + 1000*int(pt_dbm) + t)
            ch=generate_channels(cfg, rng)
            phi=make_ris_vector(cfg, rng, amplitude=1.0)
            P=make_normalized_precoders(cfg, rng)
            P *= np.sqrt(dbm_to_watt(pt_dbm) / max(np.sum(np.abs(P)**2), 1e-30))
            heff=effective_channels(ch['h_bk'], ch['h_rk'], ch['H_br'], phi)
            rates=rsma_rates(heff, ch['h_rk'], phi, P, cfg.ris_noise_w, cfg.receiver_noise_w, cfg.csi_error_w)
            samples.append(rates['sum_rate'])
        mean_rates.append(float(np.mean(samples))); std_rates.append(float(np.std(samples, ddof=1)) if trials > 1 else 0.0)
    summary={'status':'diagnostic_baseline_not_paper_AO', 'trials_per_point':trials,
             'bs_power_sweep_dbm':list(power_points_dbm), 'mean_sum_rate_bps_hz':mean_rates,
             'std_sum_rate_bps_hz':std_rates, 'seed':cfg.seed,
             'note':'Fixed random precoders/RIS; use only to validate pipeline, not as published-paper reproduction.'}
    (out/'baseline_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    fig, ax=plt.subplots(figsize=(7,4.5))
    ax.errorbar(power_points_dbm, mean_rates, yerr=std_rates, marker='o', capsize=3)
    ax.set_xlabel('BS transmit power budget (dBm)'); ax.set_ylabel('RSMA sum rate (bit/s/Hz)')
    ax.set_title('Diagnostic baseline — random precoders and RIS phases')
    ax.grid(True, alpha=0.3); fig.tight_layout(); fig.savefig(out/'baseline_sweep.png', dpi=180); plt.close(fig)
    return summary

if __name__=='__main__':
    print(json.dumps(run_sweep(), indent=2))
