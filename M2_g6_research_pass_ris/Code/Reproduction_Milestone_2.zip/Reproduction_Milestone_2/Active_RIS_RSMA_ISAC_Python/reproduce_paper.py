"""Run one paper-parameter AO scenario and save a convergence plot.

Example (Windows PowerShell):
    python reproduce_paper.py --solver MOSEK
"""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from config import SimulationConfig
from optimization.ao import run_ao


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--solver', default='MOSEK', help='CVXPY solver (default: MOSEK)')
    parser.add_argument('--output', default='results/paper_reproduction')
    parser.add_argument('--ao-iterations', type=int, default=None)
    parser.add_argument('--cccp-iterations', type=int, default=None)
    parser.add_argument('--sca-iterations', type=int, default=None)
    args = parser.parse_args()
    cfg = SimulationConfig()
    # Config is frozen; use dataclasses.replace for requested runtime controls.
    from dataclasses import replace
    updates = {}
    if args.ao_iterations is not None: updates['ao_max_iter'] = args.ao_iterations
    if args.cccp_iterations is not None: updates['cccp_max_iter'] = args.cccp_iterations
    if args.sca_iterations is not None: updates['ris_sca_max_iter'] = args.sca_iterations
    if updates: cfg = replace(cfg, **updates)
    result = run_ao(cfg=cfg, solver=args.solver, output_dir=args.output)
    out = Path(args.output)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(range(1, len(result.history)+1), result.history, marker='o')
    ax.set_xlabel('Outer AO iteration')
    ax.set_ylabel('Achieved GMI sum rate (bit/s/Hz)')
    ax.set_title('Active RIS–RSMA–ISAC: AO convergence attempt')
    ax.grid(True, alpha=0.3); fig.tight_layout()
    fig.savefig(out / 'ao_convergence.png', dpi=200); plt.close(fig)
    summary=json.loads((out/'ao_summary.json').read_text(encoding='utf-8'))
    print(json.dumps({k:summary[k] for k in ('status','outer_iterations','final_sum_rate_bps_hz','final_radar_sinr','final_bs_power_w','final_ris_power_w','max_ris_amplitude')},indent=2))
    print(f'Full trace: {out / "ao_summary.json"}')
    print(f'Solution arrays: {out / "ao_solution.npz"}')
    print(f'Convergence plot: {out / "ao_convergence.png"}')
    if summary['status'] != 'converged':
        print('NOTE: AO did not meet the stopping tolerance before its iteration limit; inspect feasibility and objective history.')
    if summary.get('final_radar_sinr') is not None and summary['final_radar_sinr'] < cfg.gamma_radar_threshold:
        print('WARNING: final radar SINR is below the configured threshold. Do not treat this run as feasible.')

if __name__ == '__main__':
    main()
