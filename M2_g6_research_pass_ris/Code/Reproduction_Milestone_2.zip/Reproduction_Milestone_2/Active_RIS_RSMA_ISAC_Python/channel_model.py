"""Rayleigh/Rician channel generation using the paper's stated path-loss laws."""
import numpy as np

def path_loss_db(distance_m: float, link: str) -> float:
    """Paper Eqs. (102)-(103); distances must be positive metres."""
    if distance_m <= 0:
        raise ValueError('distance_m must be > 0')
    d = float(distance_m)
    if link == 'indirect':
        return 35.6 + 22.0 * np.log10(d)
    if link == 'direct':
        return 32.6 + 36.7 * np.log10(d)
    raise ValueError("link must be 'direct' or 'indirect'")

def path_gain(distance_m: float, link: str) -> float:
    """Convert path loss in dB into linear power gain."""
    return 10.0 ** (-path_loss_db(distance_m, link) / 10.0)

def steering_vector(elements: int, angle_rad: float, spacing_wavelengths: float = 0.5) -> np.ndarray:
    """ULA steering vector with unit-modulus entries."""
    if elements < 1:
        raise ValueError('elements must be >= 1')
    n = np.arange(elements)
    return np.exp(1j * 2.0 * np.pi * spacing_wavelengths * n * np.sin(angle_rad)) / np.sqrt(elements)

def rayleigh(shape, rng: np.random.Generator, power_gain: float = 1.0) -> np.ndarray:
    """CN(0, power_gain) samples; power_gain is expected |h|^2 per entry."""
    if power_gain < 0:
        raise ValueError('power_gain cannot be negative')
    return np.sqrt(power_gain / 2.0) * (rng.standard_normal(shape) + 1j*rng.standard_normal(shape))

def rician(shape, rng: np.random.Generator, k_factor: float, power_gain: float = 1.0,
           los_component: np.ndarray | None = None) -> np.ndarray:
    """Rician channel: sqrt(K/(K+1))*LoS + sqrt(1/(K+1))*NLoS."""
    if k_factor < 0 or power_gain < 0:
        raise ValueError('k_factor and power_gain must be nonnegative')
    if los_component is None:
        los = np.ones(shape, dtype=complex)
    else:
        los = np.asarray(los_component, dtype=complex)
        if los.shape != tuple(shape):
            raise ValueError(f'los_component shape {los.shape} != requested {tuple(shape)}')
    los = los / max(np.sqrt(np.mean(np.abs(los)**2)), np.finfo(float).eps)
    nlos = rayleigh(shape, rng, 1.0)
    h = np.sqrt(k_factor/(k_factor+1.0))*los + np.sqrt(1.0/(k_factor+1.0))*nlos
    return np.sqrt(power_gain) * h

def generate_channels(cfg, rng: np.random.Generator) -> dict:
    """Generate channels with shapes h_bk=(K,M), H_br=(N,M), h_rk=(K,N).

    The paper uses Rayleigh direct BS-user links and Rician BS-RIS/RIS-user links.
    Geometries and angles are explicit reproducibility assumptions in config.py.
    """
    cfg.validate()
    g_direct = path_gain(cfg.bs_user_distance_m, 'direct')
    g_indirect_br = path_gain(cfg.bs_ris_distance_m, 'indirect')
    g_indirect_ru = path_gain(cfg.ris_user_distance_m, 'indirect')
    h_bk = rayleigh((cfg.K, cfg.M), rng, g_direct)
    # Simple fixed-angle LoS array response, normalized to average entry power 1.
    a_r = steering_vector(cfg.N, angle_rad=0.35, spacing_wavelengths=cfg.element_spacing_wavelengths)
    a_b = steering_vector(cfg.M, angle_rad=-0.2, spacing_wavelengths=cfg.element_spacing_wavelengths)
    los_br = np.outer(a_r, np.conjugate(a_b)) * np.sqrt(cfg.N*cfg.M)
    H_br = rician((cfg.N, cfg.M), rng, cfg.rician_k, g_indirect_br, los_br)
    h_rk = np.empty((cfg.K, cfg.N), dtype=complex)
    for k in range(cfg.K):
        a_user = steering_vector(cfg.N, angle_rad=(-0.45 + 0.2*k), spacing_wavelengths=cfg.element_spacing_wavelengths)
        h_rk[k] = rician((cfg.N,), rng, cfg.rician_k, g_indirect_ru, a_user)
    return {'h_bk': h_bk, 'H_br': H_br, 'h_rk': h_rk}
