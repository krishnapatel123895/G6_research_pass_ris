"""Alternating optimization implementation based on the paper's P3/P6 surrogates.



Important: the paper's printed covariance notation and some radar/CSI terms are

ambiguous. This module implements the equations described in the accompanying

REPRODUCTION_NOTES.md using explicit independent-error covariance expansions.

It is a research implementation to validate against the paper, not a claim of

bit-for-bit author-code equivalence. CVXPY and MOSEK are required.

"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

import cvxpy as cp



from config import SimulationConfig

from model import (effective_channels, active_ris_power, transmit_power,

                   paper_gmi_rates, radar_sinr_paper, user_error_covariance,

                   radar_error_covariance)

from radar_model import radar_effective_channel





@dataclass

class BlockResult:

    precoders: np.ndarray

    phi: np.ndarray

    status: str

    objective: float

    history: list[float]

    diagnostics: dict





def _hermitian_outer(h_row: np.ndarray) -> np.ndarray:

    h_row = np.asarray(h_row)

    return np.outer(np.conjugate(h_row), h_row)





def _trace_real(A, W):

    return cp.real(cp.trace(A @ W))





def _noise_user(cfg, h_rk_row, phi):

    return float(cfg.receiver_noise_w + cfg.ris_noise_w * np.sum(np.abs(h_rk_row * phi)**2))





def _radar_terms(cfg, H_m, H_n, H_br, phi):

    Hr = radar_effective_channel(H_m, H_n, H_br, phi)

    G = Hr.conj().T @ Hr

    Sigma = radar_error_covariance(H_n, phi, H_br, cfg.csi_error_w)

    return Hr, G, Sigma





def _initial_precoders(cfg, ch, H_m, H_n, phi, rng):

    M, K = cfg.M, cfg.K

    """Radar-focused feasible-leaning initial point; not an optimizer."""

    Hr, _, _ = _radar_terms(cfg, H_m, H_n, ch['H_br'], phi)

    vals, vecs = np.linalg.eigh(Hr.conj().T @ Hr)

    radar_vec = vecs[:, np.argmax(vals)]

    # Construct communication directions in the approximate radar nullspace.

    Q, _ = np.linalg.qr(np.column_stack([radar_vec, np.eye(M, dtype=complex)]))

    null = Q[:, 1:]

    P = np.zeros((M, K+2), dtype=complex)

    P[:, -1] = radar_vec / max(np.linalg.norm(radar_vec), 1e-15)

    for j in range(K+1):

        raw = (rng.standard_normal(M) + 1j*rng.standard_normal(M))/np.sqrt(2)

        if null.shape[1]:



            raw = null @ (null.conj().T @ raw)

        if np.linalg.norm(raw) < 1e-12:

            raw = rng.standard_normal(M) + 1j*rng.standard_normal(M)

        P[:, j] = raw / np.linalg.norm(raw)

    # Allocate most power to radar initially to help satisfy Gamma_th=2.

    powers = np.array([0.04] + [0.06/cfg.K]*cfg.K + [0.78])

    P *= np.sqrt(cfg.bs_power_w * powers)[None, :]

    # Reduce all streams together if active-RIS power is above its budget.

    pr = active_ris_power(ch['H_br'], P, phi, cfg.ris_noise_w)

    if pr > cfg.ris_power_w:

        P *= np.sqrt(cfg.ris_power_w/pr) * 0.98

    return P





def solve_bs_sdr_cccp(cfg: SimulationConfig, ch: dict, phi: np.ndarray,

                      H_m: np.ndarray, H_n: np.ndarray, P_start: np.ndarray,

                      solver: str = 'MOSEK') -> tuple[np.ndarray, dict]:

    """Solve the BS covariance SDR/CCCP block derived from paper Eqs. (55)-(69).



    Uses one Hermitian PSD covariance W_i per stream; this is equivalent to the

    block-diagonal quadratic forms in the paper's stacked SDR. A randomization

    step recovers rank-one precoders and checks original power/radar constraints.

    """

    K, M = cfg.K, cfg.M

    nstreams = K + 2

    heff = effective_channels(ch['h_bk'], ch['h_rk'], ch['H_br'], phi)

    Husers = [_hermitian_outer(heff[k]) for k in range(K)]

    Sigmas = [user_error_covariance(ch['h_rk'][k], ch['H_br'], phi, cfg.csi_error_w) for k in range(K)]

    noise = [_noise_user(cfg, ch['h_rk'][k], phi) for k in range(K)]

    power_scale = max(noise)

    Hr, Gr, Sigmar = _radar_terms(cfg, H_m, H_n, ch['H_br'], phi)

    radar_noise = float(cfg.radar_noise_w + cfg.ris_noise_w*np.linalg.norm(H_n @ np.diag(phi), 'fro')**2)



    W = [cp.Variable((M, M), hermitian=True, name=f'W_{i}') for i in range(nstreams)]

    alpha = cp.Variable(K, name='alpha'); beta = cp.Variable(K, name='beta')

    gamma = cp.Variable(K, name='gamma'); delta = cp.Variable(K, name='delta')

    common_floor = cp.Variable(name='common_floor')

    constraints = [Wj >> 0 for Wj in W]
    constraints += [common_floor >= 0]

    constraints += [sum(cp.real(cp.trace(Wj)) for Wj in W) <= cfg.bs_power_w]



    # Active RIS radiated power, affine in the lifted stream covariances.

    Br = ch['H_br'].conj().T @ np.diag(np.abs(phi)**2) @ ch['H_br']

    ris_expr = sum(_trace_real(Br, Wj) for Wj in W) + cfg.ris_noise_w*np.sum(np.abs(phi)**2)

    constraints += [ris_expr <= cfg.ris_power_w]



    # Radar SINR: |H_r p_r|^2 >= Gamma_th*(all other estimated echo power + all CSI-error power + noise).

    radar_idx = nstreams - 1

    radar_error_expr = sum(_trace_real(Sigmar, Wj) for Wj in W)

    radar_interference = sum(_trace_real(Gr, W[j]) for j in range(nstreams) if j != radar_idx)

    constraints += [_trace_real(Gr, W[radar_idx]) >= cfg.gamma_radar_threshold*(radar_interference + radar_error_expr + radar_noise)]



    # Initialize CCCP linearization point from current rank-one precoders.

    W0 = [np.outer(P_start[:, j], np.conjugate(P_start[:, j])) for j in range(nstreams)]

    def values_for(Wvals, k):

        total = sum(float(np.real(np.trace((Husers[k] + Sigmas[k]) @ X))) for X in Wvals) + noise[k]

        b = sum(float(np.real(np.trace((Husers[k] + Sigmas[k]) @ X))) for j, X in enumerate(Wvals) if j != 0) + noise[k]

        d = sum(float(np.real(np.trace((Husers[k] + Sigmas[k]) @ X))) for j, X in enumerate(Wvals) if j not in (0, k+1)) + noise[k]

        return (max(total / power_scale, 1e-20), max(b / power_scale, 1e-20), max(d / power_scale, 1e-20),)

    old_beta = np.array([np.log(values_for(W0,k)[1]) for k in range(K)])

    old_delta = np.array([np.log(values_for(W0,k)[2]) for k in range(K)])

    old_alpha = np.array([np.log(values_for(W0,k)[0]) for k in range(K)])

    old_gamma = old_beta.copy()

    history=[]; status='not_solved'

    for it in range(cfg.cccp_max_iter):

        cons = list(constraints)

        for k in range(K):

            A = Husers[k] + Sigmas[k]

            total = (sum(_trace_real(A, Wj) for Wj in W) + noise[k]) / power_scale

            b = (sum(_trace_real(A, W[j]) for j in range(nstreams) if j != 0) + noise[k]) / power_scale

            d = (sum(_trace_real(A, W[j]) for j in range(nstreams) if j not in (0, k+1)) + noise[k]) / power_scale

            cons += [total >= cp.exp(alpha[k]), b >= cp.exp(gamma[k])]

            cons += [b <= np.exp(old_beta[k])*(1 + beta[k] - old_beta[k])]

            cons += [d <= np.exp(old_delta[k])*(1 + delta[k] - old_delta[k])]

            cons += [alpha[k] - beta[k] >= common_floor]

        objective = cp.Maximize((cp.sum(gamma-delta) + common_floor)/np.log(2))

        problem = cp.Problem(objective, cons)

        if not problem.is_dcp():

            raise RuntimeError('BS SDR/CCCP subproblem failed CVXPY DCP validation; inspect the CCCP constraints in optimization/ao.py.')

        try:
            problem.solve(solver=solver, verbose=True)
        except Exception as exc:
            print("Solver exception:", repr(exc))
            print("Problem status:", problem.status)
            print("Problem value:", problem.value)
            print("Solver stats:", problem.solver_stats)
            raise RuntimeError(
                f'BS SDR/CCCP solve failed with requested solver {solver}: {exc}'
            ) from exc

        status = str(problem.status)

        if problem.status not in (cp.OPTIMAL, cp.OPTIMAL_INACCURATE):

            raise RuntimeError(f'BS SDR/CCCP subproblem status: {problem.status}; radar feasibility may fail under current assumed geometry.')

        current = [np.asarray(X.value) for X in W]

        history.append(float(problem.value))

        new_beta = np.asarray(beta.value).reshape(-1); new_delta=np.asarray(delta.value).reshape(-1)

        if it > 0 and abs(history[-1]-history[-2]) <= cfg.tolerance*max(1.0, abs(history[-2])):

            break

        old_beta, old_delta = new_beta, new_delta

        old_alpha, old_gamma = np.asarray(alpha.value).reshape(-1), np.asarray(gamma.value).reshape(-1)

    covs = [0.5*(X+X.conj().T) for X in current]

    Pbest, best_rate, best_diag = _recover_rank_one(cfg, ch, phi, H_m, H_n, covs, P_start)

    return Pbest, {'status':status,'cccp_iterations':len(history),'surrogate_history':history,

                   'rank_one_sum_rate':best_rate, **best_diag}





def _recover_rank_one(cfg, ch, phi, H_m, H_n, covs, P_start):

    """Gaussian randomization of relaxed stream covariances, as described after Eq. (69)."""

    rng=np.random.default_rng(cfg.seed+997)

    K, M = cfg.K, cfg.M

    bestP=np.asarray(P_start).copy(); best=-np.inf; bestdiag={}

    candidates=[bestP]

    eig_data=[]

    for C in covs:

        vals, vecs=np.linalg.eigh(0.5*(C+C.conj().T)); vals=np.maximum(vals,0)

        eig_data.append((vals,vecs))

    for _ in range(cfg.randomization_trials):

        P=np.zeros((M,K+2),dtype=complex)

        for j,(vals,vecs) in enumerate(eig_data):

            z=(rng.standard_normal(M)+1j*rng.standard_normal(M))/np.sqrt(2)

            P[:,j]=vecs @ (np.sqrt(vals)*z)

        pwr=np.sum(np.abs(P)**2)

        if pwr>cfg.bs_power_w: P*=np.sqrt(cfg.bs_power_w/pwr)

        ris=active_ris_power(ch['H_br'],P,phi,cfg.ris_noise_w)

        if ris>cfg.ris_power_w: P*=np.sqrt(cfg.ris_power_w/ris)*0.999

        candidates.append(P)

    for P in candidates:

        heff=effective_channels(ch['h_bk'],ch['h_rk'],ch['H_br'],phi)

        rates=paper_gmi_rates(heff,ch['h_rk'],ch['H_br'],phi,P,cfg.ris_noise_w,cfg.receiver_noise_w,cfg.csi_error_w)

        Hr=radar_effective_channel(H_m,H_n,ch['H_br'],phi)

        rad=radar_sinr_paper(Hr,H_n,phi,ch['H_br'],P,cfg.ris_noise_w,cfg.radar_noise_w,cfg.csi_error_w)

        tp=transmit_power(P); rp=active_ris_power(ch['H_br'],P,phi,cfg.ris_noise_w)

        feasible=tp <= cfg.bs_power_w*(1+1e-6) and rp <= cfg.ris_power_w*(1+1e-6) and rad >= cfg.gamma_radar_threshold*(1-1e-5)

        score=rates['sum_rate'] if feasible else rates['sum_rate']-1000*max(0,cfg.gamma_radar_threshold-rad)

        if score>best:

            best=score; bestP=P.copy(); bestdiag={'radar_sinr':rad,'bs_power_w':tp,'ris_power_w':rp,'feasible':bool(feasible),'common_rate':rates['common_rate'],'private_rates':rates['private_rates'].tolist()}

    heff=effective_channels(ch['h_bk'],ch['h_rk'],ch['H_br'],phi)

    best_rate=float(paper_gmi_rates(heff,ch['h_rk'],ch['H_br'],phi,bestP,cfg.ris_noise_w,cfg.receiver_noise_w,cfg.csi_error_w)['sum_rate'])

    return bestP, best_rate, bestdiag





def solve_ris_sca(cfg: SimulationConfig, ch: dict, P: np.ndarray, phi_start: np.ndarray,

                  H_m: np.ndarray, H_n: np.ndarray, solver: str = 'MOSEK') -> tuple[np.ndarray, dict]:

    """Solve the RIS P6 block using auxiliary variables and iterative DC/SCA.



    Implements the affine channel decompositions (75)-(79), denominator slacks

    (81)-(82), product DC lower bounds (87)-(88), active-RIS power constraint,

    element-amplitude constraints, and radar numerator tangent (95). The radar

    and CSI covariance expansions are documented assumptions where the paper's

    printed expressions are ambiguous.

    """

    K, M = cfg.K, cfg.M

    N = cfg.N

    nstreams = K + 2

    ridx = nstreams - 1

    Hbr = ch['H_br']; hbk = ch['h_bk']; hrk = ch['h_rk']

    P = np.asarray(P)

    # Normalize user-side powers to avoid mixing ~1e-11 W denominator slacks
    # with order-one SINR variables in the DC product approximation.
    user_power_scale = max(float(cfg.receiver_noise_w), float(cfg.ris_noise_w), 1e-30)

    phi_anchor = np.asarray(phi_start, dtype=complex).copy()

    maxamp = float(np.max(np.abs(phi_anchor)))

    if maxamp > cfg.vmax:

        phi_anchor *= cfg.vmax / maxamp

    def p_ris(v):

        return active_ris_power(Hbr, P, v, cfg.ris_noise_w)

    if p_ris(phi_anchor) > cfg.ris_power_w:

        phi_anchor *= np.sqrt(cfg.ris_power_w / p_ris(phi_anchor)) * 0.95



    HP = Hbr @ P

    x = np.empty((K, nstreams, N), dtype=complex)

    z = np.empty((K, nstreams), dtype=complex)

    for k in range(K):

        for j in range(nstreams):

            x[k, j] = hrk[k] * HP[:, j]

            z[k, j] = hbk[k] @ P[:, j]

    A = [H_n @ np.diag(HP[:, j]) for j in range(nstreams)]

    q = [H_m @ P[:, j] for j in range(nstreams)]



    history = []

    statuses = []

    for sca_it in range(cfg.ris_sca_max_iter):

        # Evaluate the exact local denominators and SINRs at this SCA anchor.

        y_anchor = np.array([[x[k, j] @ phi_anchor + z[k, j]

                              for j in range(nstreams)] for k in range(K)])

        lambda_c0 = np.zeros(K); lambda_p0 = np.zeros(K)

        rho_c0 = np.zeros(K); rho_p0 = np.zeros(K)

        for k in range(K):

            Sigma_k = user_error_covariance(hrk[k], Hbr, phi_anchor, cfg.csi_error_w)

            err = np.array([np.real(np.vdot(P[:, j], Sigma_k @ P[:, j])) for j in range(nstreams)])

            noise_k = cfg.receiver_noise_w + cfg.ris_noise_w * np.sum(np.abs(hrk[k] * phi_anchor)**2)

            signal = np.abs(y_anchor[k])**2

            lambda_c0[k] = max(float(np.sum(signal[1:]) + np.sum(err) + noise_k) / user_power_scale, 1e-12)

            lambda_p0[k] = max(float(np.sum(signal[1:]) - signal[k+1] + np.sum(err) + noise_k) / user_power_scale, 1e-12)

            rho_c0[k] = float(signal[0] / lambda_c0[k])

            rho_p0[k] = float(signal[k+1] / lambda_p0[k])



        phi = cp.Variable(N, complex=True, name='phi')

        rho_c = cp.Variable(K, nonneg=True, name='rho_c')

        rho_p = cp.Variable(K, nonneg=True, name='rho_p')

        lam_c = cp.Variable(K, nonneg=True, name='lambda_c')

        lam_p = cp.Variable(K, nonneg=True, name='lambda_p')

        common_floor = cp.Variable(name='common_floor')

        constraints = [cp.abs(phi) <= cfg.vmax]

        constraints += [cp.sum_squares(cp.abs(cp.multiply(phi[:, None], HP)))

                        + cfg.ris_noise_w * cp.sum_squares(cp.abs(phi)) <= cfg.ris_power_w]



        def lower_tangent(y_expr, y_old_scalar):

            return 2 * cp.real(np.conjugate(y_old_scalar) * y_expr) - float(np.abs(y_old_scalar)**2)



        for k in range(K):

            ys = [x[k, j] @ phi + z[k, j] for j in range(nstreams)]

            ris_noise_expr = cfg.ris_noise_w * cp.sum_squares(cp.abs(cp.multiply(hrk[k], phi)))

            error_expr = 0

            for j in range(nstreams):

                error_expr += cfg.csi_error_w * float(np.linalg.norm(P[:, j])**2)

                error_expr += cfg.csi_error_w * cp.sum_squares(cp.abs(cp.multiply(phi, HP[:, j])))

                error_expr += (cfg.csi_error_w * cp.sum_squares(cp.abs(cp.multiply(hrk[k], phi)))

                               * float(np.linalg.norm(P[:, j])**2))

            den_c = (sum(cp.square(cp.abs(ys[j])) for j in range(1, nstreams))
                     + error_expr + ris_noise_expr + cfg.receiver_noise_w) / user_power_scale

            den_p = (sum(cp.square(cp.abs(ys[j])) for j in range(1, nstreams) if j != k+1)
                     + error_expr + ris_noise_expr + cfg.receiver_noise_w) / user_power_scale

            constraints += [den_c <= lam_c[k], den_p <= lam_p[k]]

            sig_c = lower_tangent(ys[0], y_anchor[k, 0]) / user_power_scale

            sig_p = lower_tangent(ys[k+1], y_anchor[k, k+1]) / user_power_scale

            lc0, rc0 = lambda_c0[k], rho_c0[k]

            lp0, rp0 = lambda_p0[k], rho_p0[k]

            rhs_c = 0.25 * ((lam_c[k] + rho_c[k])**2 - (lc0-rc0)**2

                            - 2*(lc0-rc0)*((lam_c[k]-rho_c[k])-(lc0-rc0)))

            rhs_p = 0.25 * ((lam_p[k] + rho_p[k])**2 - (lp0-rp0)**2

                            - 2*(lp0-rp0)*((lam_p[k]-rho_p[k])-(lp0-rp0)))

            constraints += [sig_c >= rhs_c, sig_p >= rhs_p]

            constraints += [common_floor <= cp.log(1 + rho_c[k]) / np.log(2)]



        # Radar numerator tangent and convex denominator, following Eq. (95).

        radar_anchor = [A[j] @ phi_anchor + q[j] for j in range(nstreams)]

        radar_expr = [A[j] @ phi + q[j] for j in range(nstreams)]

        num_old = radar_anchor[ridx]

        radar_num_lb = 2*cp.real(cp.sum(cp.multiply(np.conjugate(num_old), radar_expr[ridx]))) - float(np.linalg.norm(num_old)**2)

        radar_den = sum(cp.sum_squares(cp.abs(radar_expr[j])) for j in range(nstreams) if j != ridx)

        for j in range(nstreams):

            radar_den += cfg.csi_error_w * (

                M*float(np.linalg.norm(P[:, j])**2)

                + M*cp.sum_squares(cp.abs(cp.multiply(phi, HP[:, j])))

                + cp.sum_squares(cp.abs(H_n @ cp.diag(phi))) * float(np.linalg.norm(P[:, j])**2))

        radar_den += cfg.ris_noise_w * cp.sum_squares(cp.abs(H_n @ cp.diag(phi))) + cfg.radar_noise_w

        constraints += [radar_num_lb >= cfg.gamma_radar_threshold * radar_den]

        objective = cp.Maximize(cp.sum(cp.log(1 + rho_p))/np.log(2) + common_floor)

        problem = cp.Problem(objective, constraints)

        if not problem.is_dcp():

            raise RuntimeError('RIS DC/SCA subproblem failed CVXPY DCP validation; inspect the tangent/product constraints in optimization/ao.py.')

        try:
            problem.solve(solver=solver, verbose=False)
        except Exception as exc:
            print("\n--- RIS SCA SOLVER DIAGNOSTICS ---")
            print("Exception:", repr(exc))
            print("Status:", problem.status)
            print("Value:", problem.value)
            print("Solver stats:", problem.solver_stats)
            print("User power normalization (W):", user_power_scale)
            raise RuntimeError(
                f'RIS SCA solve failed with requested solver {solver}: {exc}'
            ) from exc

        statuses.append(str(problem.status))

        if problem.status not in (cp.OPTIMAL, cp.OPTIMAL_INACCURATE) or phi.value is None:

            if sca_it == 0:

                raise RuntimeError(f'RIS SCA subproblem status: {problem.status}; inspect radar feasibility and assumed geometry.')

            break

        phi_new = np.asarray(phi.value).reshape(-1)

        phi_new = np.minimum(1.0, cfg.vmax / np.maximum(np.abs(phi_new), 1e-30)) * phi_new

        if p_ris(phi_new) > cfg.ris_power_w:

            phi_new *= np.sqrt(cfg.ris_power_w / p_ris(phi_new)) * 0.999

        heff_new = effective_channels(hbk, hrk, Hbr, phi_new)

        rates_new = paper_gmi_rates(heff_new, hrk, Hbr, phi_new, P, cfg.ris_noise_w, cfg.receiver_noise_w, cfg.csi_error_w)

        history.append(float(rates_new['sum_rate']))

        delta = np.linalg.norm(phi_new-phi_anchor) / max(1.0, np.linalg.norm(phi_anchor))

        phi_anchor = phi_new

        if delta <= cfg.tolerance:

            break

    Hr_final = radar_effective_channel(H_m, H_n, Hbr, phi_anchor)

    radar_final = radar_sinr_paper(Hr_final, H_n, phi_anchor, Hbr, P, cfg.ris_noise_w, cfg.radar_noise_w, cfg.csi_error_w)

    return phi_anchor, {'status':statuses[-1] if statuses else 'not_solved',

                        'sca_iterations':len(history),'actual_sum_rate_history':history,

                        'ris_power_w':p_ris(phi_anchor),

                        'max_element_amplitude':float(np.max(np.abs(phi_anchor))),

                        'radar_sinr':radar_final}



def run_ao(cfg: SimulationConfig | None = None, solver: str = 'MOSEK', output_dir: str = 'results') -> BlockResult:

    """Run outer alternating optimization and save detailed reproducibility outputs."""

    import json

    from pathlib import Path

    from channel_model import generate_channels

    from radar_model import generate_radar_channels

    cfg=cfg or SimulationConfig(); cfg.validate()

    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)

    rng=np.random.default_rng(cfg.seed)

    ch=generate_channels(cfg,rng); H_m,H_n=generate_radar_channels(cfg)

    phi=np.ones(cfg.N,dtype=complex)*0.25

    P=_initial_precoders(cfg,ch,H_m,H_n,phi,rng)

    # Ensure RIS power budget at initialization.

    pr=active_ris_power(ch['H_br'],P,phi,cfg.ris_noise_w)

    if pr>cfg.ris_power_w: P*=np.sqrt(cfg.ris_power_w/pr)*0.95

    history=[]; details=[]; status='max_iterations'

    for outer in range(cfg.ao_max_iter):

        P,bsdiag=solve_bs_sdr_cccp(cfg,ch,phi,H_m,H_n,P,solver=solver)

        phi,risdiag=solve_ris_sca(cfg,ch,P,phi,H_m,H_n,solver=solver)

        heff=effective_channels(ch['h_bk'],ch['h_rk'],ch['H_br'],phi)

        rates=paper_gmi_rates(heff,ch['h_rk'],ch['H_br'],phi,P,cfg.ris_noise_w,cfg.receiver_noise_w,cfg.csi_error_w)

        Hr=radar_effective_channel(H_m,H_n,ch['H_br'],phi)

        rad=radar_sinr_paper(Hr,H_n,phi,ch['H_br'],P,cfg.ris_noise_w,cfg.radar_noise_w,cfg.csi_error_w)

        pr=active_ris_power(ch['H_br'],P,phi,cfg.ris_noise_w); pt=transmit_power(P)

        obj=float(rates['sum_rate']); history.append(obj)

        feasible = (pt <= cfg.bs_power_w*(1+1e-6) and pr <= cfg.ris_power_w*(1+1e-6)

                    and np.max(np.abs(phi)) <= cfg.vmax*(1+1e-6)

                    and rad >= cfg.gamma_radar_threshold*(1-1e-5))

        details.append({'outer_iteration':outer+1,'sum_rate_bps_hz':obj,'radar_sinr':rad,'bs_power_w':pt,'ris_power_w':pr,'max_ris_amplitude':float(np.max(np.abs(phi))),'feasible':bool(feasible),'bs_block':bsdiag,'ris_block':risdiag})

        if outer>0 and abs(history[-1]-history[-2]) <= cfg.tolerance*max(1.0,abs(history[-2])):

            status='converged'; break

    final_feasible = bool(details[-1]['feasible']) if details else False

    if status == 'converged' and not final_feasible: status = 'converged_infeasible'

    summary={'status':status,'feasible':final_feasible,'solver_requested':solver,'scope':'paper_based_AO_reproduction_attempt_with_explicit_assumptions',

             'note':'See REPRODUCTION_NOTES.md: paper leaves target geometry/reflection parameters unspecified and has ambiguous error covariance notation. Results must be compared to paper figures before claiming exact reproduction.',

             'seed':cfg.seed,'M':cfg.M,'K':cfg.K,'N':cfg.N,'bs_power_dbm':cfg.bs_power_dbm,'ris_power_dbm':cfg.ris_power_dbm,

             'objective_history_bps_hz':history,'final_sum_rate_bps_hz':history[-1] if history else None,

             'final_radar_sinr':details[-1]['radar_sinr'] if details else None,

             'final_bs_power_w':transmit_power(P),'final_ris_power_w':active_ris_power(ch['H_br'],P,phi,cfg.ris_noise_w),

             'max_ris_amplitude':float(np.max(np.abs(phi))),'outer_iterations':len(history),'iterations':details}

    (out/'ao_summary.json').write_text(json.dumps(summary,indent=2,default=lambda x: x.item() if hasattr(x,'item') else str(x)),encoding='utf-8')

    np.savez_compressed(out/'ao_solution.npz',precoders=P,phi=phi,H_m=H_m,H_n=H_n,H_br=ch['H_br'],h_bk=ch['h_bk'],h_rk=ch['h_rk'])

    return BlockResult(P,phi,status,history[-1] if history else float('nan'),history,summary)
