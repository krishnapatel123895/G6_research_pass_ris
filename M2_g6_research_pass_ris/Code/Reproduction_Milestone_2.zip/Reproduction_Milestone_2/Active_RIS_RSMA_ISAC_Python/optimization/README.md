# Optimization implementation status

`ao.py` now implements a paper-based alternating-optimization attempt:

1. **BS precoder block:** per-stream Hermitian PSD covariance relaxation for the stacked quadratic forms, auxiliary log variables, CCCP linearization, BS/RIS power constraints, and a radar-SINR constraint (paper equations 46–69). Gaussian randomization recovers rank-one stream precoders and rechecks feasibility.
2. **Active RIS block:** complex reflection vector, element-amplitude and radiated-power constraints, common/private SINR slacks, DC product bounds, SCA tangents for communication/radar signal powers, and an achievable-rate objective (paper equations 70–96).
3. **Outer AO loop:** alternates the blocks and saves objective/constraint histories.

## Critical caveat

This is now real optimization code, but it is not yet scientifically validated as an exact reproduction. The paper leaves target geometry/reflection coefficients and some covariance details underspecified, and the RIS/radar covariance expressions require an explicit interpretation. See `REPRODUCTION_NOTES.md`. The current tests validate physical-model helper functions and project integrity; they do not prove that CVXPY accepts both complete convex subproblems or that MOSEK converges on the default scenario. Run `python reproduce_paper.py --solver MOSEK` and record any solver status/traceback. Do not report infeasible runs as paper results.

## Main entry points

- `python optimization/smoke_mosek.py` — tests only the solver installation/license.
- `python reproduce_paper.py --solver MOSEK` — attempts one AO scenario and saves a convergence graph and arrays.
- `python experiments/run_power_sweep.py --solver MOSEK` — performs the AO-based BS power sweep.
- `python -m pytest -q` — runs unit tests; the MOSEK smoke unit test is skipped if CVXPY is unavailable.
