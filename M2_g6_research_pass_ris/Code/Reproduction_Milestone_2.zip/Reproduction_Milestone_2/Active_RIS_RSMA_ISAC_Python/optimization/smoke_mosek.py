"""Tiny CVXPY–MOSEK test; no research model is solved here."""
import cvxpy as cp

def run():
    if 'MOSEK' not in cp.installed_solvers():
        raise RuntimeError('MOSEK is not installed in the current Python environment.')
    x=cp.Variable(name='x')
    problem=cp.Problem(cp.Minimize(cp.square(x-2)), [x >= 0])
    problem.solve(solver=cp.MOSEK)
    assert problem.status in ('optimal','optimal_inaccurate'), problem.status
    assert x.value is not None and abs(float(x.value)-2.0) < 1e-3, x.value
    return problem.status, float(x.value)

if __name__=='__main__':
    status, value=run(); print(f'PASS: status={status}; x={value:.6f}')
