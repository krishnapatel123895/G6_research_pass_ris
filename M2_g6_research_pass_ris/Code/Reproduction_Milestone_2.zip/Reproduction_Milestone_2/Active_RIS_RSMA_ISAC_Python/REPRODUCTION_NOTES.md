# Paper reproduction notes and equation-to-code audit

Reference: A. S. Parihar, C. H. Chen, and C.-P. Li, “Beamforming Design for Enhanced Sum Rate in Active RIS-RSMA-Assisted ISAC Systems Under Imperfect CSIT/CSIR,” IEEE Transactions on Vehicular Technology, vol. 75, no. 6, June 2026, DOI: 10.1109/TVT.2025.3648447.

## Scope and scientific honesty

The project now contains an AO optimization implementation based on the paper's BS SDR/CCCP formulation (P1–P3, equations 46–69) and RIS auxiliary-variable/DC/SCA formulation (P4–P6, equations 70–96). It is an implementation attempt requiring execution with CVXPY/MOSEK and comparison against the paper. Do not claim author-code equivalence or exact figure reproduction until the solver run is feasible and published curves are compared.

The article itself does not specify all numerical details required to uniquely reproduce its figures. In particular, Table I does not provide target angles/reflection coefficients, all user/BS/RIS coordinates, the radar receiver-noise value, Monte Carlo count/seeds, or all solver/randomization details. Those have explicit assumptions in `config.py`; change them only with an entry in the experiment notes. The printed covariance/radar equations also have notation/OCR ambiguity, so this project uses the independent-error covariance interpretation documented below.

## Equation-to-code mapping

| Paper | Meaning | Code |
|---|---|---|
| (1)–(5) | Common, private and radar streams; active RIS reflection | `model.py`, `optimization/ao.py` |
| (6) | Active RIS radiated power including amplified thermal noise | `model.active_ris_power`, AO RIS-power constraints |
| (7)–(10) | Effective user channel and common/private SINR | `model.effective_channels`, `model.paper_gmi_rates` |
| (11)–(17) | Radar echo channel and SINR/rate | `radar_model.py`, `model.radar_sinr_paper` |
| (18)–(24) | Imperfect channel estimates and effective channels | `model.user_error_covariance`, `model.radar_error_covariance` |
| (34), (40), (42), (44) | GMI rates under channel estimation error | `model.paper_gmi_rates`, `model.radar_sinr_paper` |
| (45)–(54) | Joint optimization, stacked quadratic forms | `optimization/ao.py::solve_bs_sdr_cccp` |
| (55)–(69) | Auxiliary log variables, SDR and CCCP tangents | `optimization/ao.py::solve_bs_sdr_cccp` |
| (70)–(88) | RIS optimization, affine signal decomposition and DC lower bounds | `optimization/ao.py::solve_ris_sca` |
| (89)–(96) | Radar constraint and convex RIS subproblem | `optimization/ao.py::solve_ris_sca` |
| (99)–(103) | Rician/Rayleigh channels and path-loss laws | `channel_model.py` |

## Important implementation interpretations

1. `SimulationConfig.csi_error_w` is converted from the paper's listed -60 dBm to a linear value. The paper labels this as a channel-error variance; that unit convention is unusual and is kept as listed, not silently changed.
2. Effective communication-channel error covariance assumes independent i.i.d. errors on direct BS-user, RIS-user, and BS-RIS links. The expansion is `sigma_e^2 * (I + H_BR^H diag(|phi|^2) H_BR + ||h_R,k diag(phi)||^2 I)`.
3. Radar effective channel uses `H_r = H_m + H_n diag(phi) H_BR`. Radar error covariance is the independent-error expansion in `model.radar_error_covariance`.
4. Target angles, target response coefficients, and radar receiver noise use explicit defaults in `config.py` because Table I does not uniquely specify them. They must be tuned only with a documented source/assumption.
5. The BS SDR uses per-stream Hermitian PSD covariance blocks, equivalent to the paper's block-diagonal quadratic forms for the constraints/objective. Randomized rank-one recovery is checked against the original power and radar constraints.
6. The RIS SCA uses one or more tangent updates, checks amplitude/power limits, and is embedded in the outer AO loop. Due to nonconvexity, local solutions and numerical infeasibility are possible.
7. `baseline.py` remains a random-precoder diagnostic only. It must not be used as the optimized paper result.

## Run order (Windows PowerShell)

```powershell
python -m pip install -r requirements.txt
python -m pytest -q
python verify_environment.py
python optimization/smoke_mosek.py
python reproduce_paper.py --solver MOSEK
python experiments/run_power_sweep.py --solver MOSEK
```

First run `reproduce_paper.py` with default settings. If a block is infeasible, save the full traceback and `results/paper_reproduction/ao_summary.json` if created. Do not silently replace MOSEK with a different solver in final results. SCS fallback is for debugging only and must be recorded in the experiment log.

## Figure status

- Figure 2: `reproduce_paper.py` saves an AO convergence curve. The paper also compares alternative algorithms/access schemes, so this is not yet the complete Fig. 2 panel.
- Figure 3: `experiments/run_power_sweep.py` implements an AO-based BS-power sweep. Run time can be substantial.
- Figure 4/6/7/9 study variables: `experiments/run_parameter_sweep.py` supports user count, RIS-element count, radar threshold, BS–RIS distance, CSI-error setting and antenna count. These are single-scheme AO sweeps, not every multi-curve panel in the paper.
- Figure 8: the radar-threshold sweep additionally plots a radar-rate proxy. Verify it against the exact Fig. 8 metric/axes.
- Figure 10: `experiments/plot_beampattern.py` produces a BS transmit beampattern proxy; exact target steering/normalization must be reconciled with the paper.
- Figure 2 multi-scheme convergence and Figure 5 RIS-mode/access-scheme baselines are still incomplete; passive/no-RIS/transmissive-RIS and SDMA comparators require their own correctly constrained models.

## Validation checklist before calling this a reproduction

- [ ] MOSEK solves both optimization blocks without inaccurate/infeasible statuses.
- [ ] `sum ||p_i||^2 <= Pt`, `PR <= PRIS`, `|phi_n| <= vmax`, and radar SINR >= threshold are verified numerically at every AO iteration.
- [ ] Objective and true sum-rate histories are recorded separately; no unverified monotonicity claim.
- [ ] Sensitivity to random seed and target geometry is evaluated.
- [ ] Figures 2–10 are compared to the paper, with assumptions and deviations stated.
