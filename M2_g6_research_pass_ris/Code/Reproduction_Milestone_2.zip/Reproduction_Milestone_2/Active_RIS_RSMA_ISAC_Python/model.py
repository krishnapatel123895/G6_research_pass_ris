
"""Core channel, power, RSMA-rate, and CSI-error model functions.

Conventions:
    h_bk: (K, M) direct BS-to-user channels
    h_rk: (K, N) RIS-to-user channels
    H_br: (N, M) BS-to-RIS channel
    phi: (N,) diagonal of the RIS matrix
    P: (M, K+2) precoders [common, private users, radar]

The diagnostic functions are simplified models. The paper-oriented
functions use the stated independent, i.i.d. channel-error assumptions.
Their correctness must still be validated against the paper equations.
"""
from __future__ import annotations

import numpy as np


def _as_complex_array(
    name: str, value: np.ndarray, ndim: int | None = None
) -> np.ndarray:
    arr = np.asarray(value, dtype=complex)
    if ndim is not None and arr.ndim != ndim:
        raise ValueError(
            f"{name} must have {ndim} dimensions; got shape {arr.shape}."
        )
    if not np.all(np.isfinite(arr)):
        raise ValueError(f"{name} contains NaN or infinite values.")
    return arr


def _nonnegative_finite(name: str, value: float) -> float:
    val = float(value)
    if not np.isfinite(val) or val < 0:
        raise ValueError(f"{name} must be finite and non-negative.")
    return val


def effective_channels(
    h_bk: np.ndarray,
    h_rk: np.ndarray,
    H_br: np.ndarray,
    phi: np.ndarray,
) -> np.ndarray:
    """Effective BS-user channels: h_eff = h_B + h_R diag(phi) H_BR."""
    h_bk = _as_complex_array("h_bk", h_bk, 2)
    h_rk = _as_complex_array("h_rk", h_rk, 2)
    H_br = _as_complex_array("H_br", H_br, 2)
    phi = _as_complex_array("phi", phi, 1)

    K, M = h_bk.shape

    if h_rk.shape[0] != K:
        raise ValueError("h_bk and h_rk must have the same user count.")
    if h_rk.shape[1] != phi.size or H_br.shape != (phi.size, M):
        raise ValueError("Expected h_rk=(K,N), phi=(N,), H_br=(N,M).")

    return h_bk + (h_rk * phi[None, :]) @ H_br


def active_ris_power(
    H_br: np.ndarray,
    precoders: np.ndarray,
    phi: np.ndarray,
    ris_noise_w: float,
) -> float:
    """Active RIS output power in watts.

    P_R = sum_i ||Phi H_BR p_i||^2 + sigma_d^2 ||Phi||_F^2.
    """
    H_br = _as_complex_array("H_br", H_br, 2)
    P = _as_complex_array("precoders", precoders, 2)
    phi = _as_complex_array("phi", phi, 1)
    ris_noise_w = _nonnegative_finite("ris_noise_w", ris_noise_w)

    if H_br.shape != (phi.size, P.shape[0]):
        raise ValueError("Expected H_br=(N,M), P=(M,S), phi=(N,).")

    amplified = (phi[:, None] * H_br) @ P
    signal_power = float(np.sum(np.abs(amplified) ** 2))
    noise_power = ris_noise_w * float(np.sum(np.abs(phi) ** 2))

    return signal_power + noise_power


def transmit_power(precoders: np.ndarray) -> float:
    """Total BS transmit power in watts."""
    P = _as_complex_array("precoders", precoders, 2)
    return float(np.sum(np.abs(P) ** 2))


def rsma_rates(
    h_eff: np.ndarray,
    h_rk: np.ndarray,
    phi: np.ndarray,
    precoders: np.ndarray,
    ris_noise_w: float,
    receiver_noise_w: float,
    csi_error_w: float = 0.0,
) -> dict:
    """Diagnostic RSMA rate approximation; not the full paper model."""
    h_eff = _as_complex_array("h_eff", h_eff, 2)
    h_rk = _as_complex_array("h_rk", h_rk, 2)
    phi = _as_complex_array("phi", phi, 1)
    P = _as_complex_array("precoders", precoders, 2)

    ris_noise_w = _nonnegative_finite("ris_noise_w", ris_noise_w)
    receiver_noise_w = _nonnegative_finite(
        "receiver_noise_w", receiver_noise_w
    )
    csi_error_w = _nonnegative_finite("csi_error_w", csi_error_w)

    K, M = h_eff.shape

    if h_rk.shape != (K, phi.size) or P.shape != (M, K + 2):
        raise ValueError(
            "Expected h_eff=(K,M), h_rk=(K,N), phi=(N,), P=(M,K+2)."
        )

    common_each = np.zeros(K)
    private = np.zeros(K)
    ris_noise_by_user = np.zeros(K)

    error_power = csi_error_w * float(np.sum(np.abs(P) ** 2))

    for k in range(K):
        signal = np.abs(h_eff[k] @ P) ** 2
        ris_noise = ris_noise_w * float(
            np.sum(np.abs(h_rk[k] * phi) ** 2)
        )
        ris_noise_by_user[k] = ris_noise

        common_den = (
            float(np.sum(signal[1:]))
            + ris_noise + receiver_noise_w + error_power
        )
        private_den = (
            float(np.sum(signal[1:]) - signal[k + 1])
            + ris_noise + receiver_noise_w + error_power
        )

        common_each[k] = np.log2(
            1.0 + signal[0] / max(common_den, np.finfo(float).tiny)
        )
        private[k] = np.log2(
            1.0 + signal[k + 1]
            / max(private_den, np.finfo(float).tiny)
        )

    common = float(np.min(common_each))

    return {
        "common_rate_each_user": common_each,
        "private_rates": private,
        "common_rate": common,
        "sum_rate": common + float(np.sum(private)),
        "ris_noise_power_by_user_w": ris_noise_by_user,
    }


def make_normalized_precoders(
    cfg, rng: np.random.Generator
) -> np.ndarray:
    """Generate random precoders under the BS power budget (diagnostic)."""
    if cfg.bs_power_w <= 0:
        raise ValueError("cfg.bs_power_w must be positive.")

    P = (
        rng.standard_normal((cfg.M, cfg.K + 2))
        + 1j * rng.standard_normal((cfg.M, cfg.K + 2))
    ) / np.sqrt(2.0)

    norm = float(np.sum(np.abs(P) ** 2))
    if norm <= 0 or not np.isfinite(norm):
        raise ValueError("Could not generate finite nonzero precoders.")

    return P * np.sqrt(cfg.bs_power_w / norm)


def make_ris_vector(
    cfg, rng: np.random.Generator, amplitude: float = 1.0
) -> np.ndarray:
    """Generate random RIS phases with a constant, clipped amplitude."""
    amp = float(amplitude)

    if not np.isfinite(amp):
        raise ValueError("amplitude must be finite.")

    amp = float(np.clip(amp, 0.0, cfg.vmax))
    phases = rng.uniform(-np.pi, np.pi, cfg.N)

    return amp * np.exp(1j * phases)


def user_error_covariance(
    h_rk_row: np.ndarray,
    H_br: np.ndarray,
    phi: np.ndarray,
    csi_error_w: float,
) -> np.ndarray:
    """Effective user-channel error covariance under independent link errors.

    Uses the expansion:
      e_k = e_B,k + e_R,k Phi H_BR
            + h_R,k Phi E_BR + e_R,k Phi E_BR.

    Assumes independent i.i.d. complex Gaussian error entries with variance
    csi_error_w. The second-order product-error contribution is retained.
    """
    h_rk_row = _as_complex_array("h_rk_row", h_rk_row, 1)
    H_br = _as_complex_array("H_br", H_br, 2)
    phi = _as_complex_array("phi", phi, 1)
    sigma2 = _nonnegative_finite("csi_error_w", csi_error_w)

    M = H_br.shape[1]

    if H_br.shape[0] != phi.size or h_rk_row.size != phi.size:
        raise ValueError("Expected h_rk_row=(N,), H_br=(N,M), phi=(N,).")

    weighted_H = H_br.conj().T @ (
        np.abs(phi)[:, None] ** 2 * H_br
    )
    ris_user_gain = float(np.sum(np.abs(h_rk_row * phi) ** 2))
    product_error = sigma2**2 * float(np.sum(np.abs(phi) ** 2))

    covariance = (
        sigma2 * np.eye(M, dtype=complex)
        + sigma2 * weighted_H
        + (sigma2 * ris_user_gain + product_error)
        * np.eye(M, dtype=complex)
    )

    return 0.5 * (covariance + covariance.conj().T)


def paper_gmi_rates(
    h_eff: np.ndarray,
    h_rk: np.ndarray,
    H_br: np.ndarray,
    phi: np.ndarray,
    precoders: np.ndarray,
    ris_noise_w: float,
    receiver_noise_w: float,
    csi_error_w: float,
) -> dict:
    """GMI-style RSMA rates under the selected CSI-error covariance.

    Stream columns: [common, private user 1..K, radar].

    Estimated common-stream interference is removed for private decoding;
    residual channel-error terms remain in the denominator.
    """
    h_eff = _as_complex_array("h_eff", h_eff, 2)
    h_rk = _as_complex_array("h_rk", h_rk, 2)
    H_br = _as_complex_array("H_br", H_br, 2)
    phi = _as_complex_array("phi", phi, 1)
    P = _as_complex_array("precoders", precoders, 2)

    ris_noise_w = _nonnegative_finite("ris_noise_w", ris_noise_w)
    receiver_noise_w = _nonnegative_finite(
        "receiver_noise_w", receiver_noise_w
    )
    csi_error_w = _nonnegative_finite("csi_error_w", csi_error_w)

    K, M = h_eff.shape

    if (
        h_rk.shape != (K, phi.size)
        or H_br.shape != (phi.size, M)
        or P.shape != (M, K + 2)
    ):
        raise ValueError(
            "Expected h_eff=(K,M), h_rk=(K,N), H_br=(N,M), "
            "phi=(N,), P=(M,K+2)."
        )

    common_each = np.zeros(K)
    private = np.zeros(K)
    ris_noise_by_user = np.zeros(K)

    for k in range(K):
        Sigma_k = user_error_covariance(
            h_rk[k], H_br, phi, csi_error_w
        )

        error_by_stream = np.array([
            max(
                float(np.real(np.vdot(P[:, j], Sigma_k @ P[:, j]))),
                0.0,
            )
            for j in range(K + 2)
        ])

        signal = np.abs(h_eff[k] @ P) ** 2
        ris_noise = ris_noise_w * float(
            np.sum(np.abs(h_rk[k] * phi) ** 2)
        )
        ris_noise_by_user[k] = ris_noise
        equivalent_noise = receiver_noise_w + ris_noise

        common_den = (
            float(np.sum(signal[1:]))
            + float(np.sum(error_by_stream))
            + equivalent_noise
        )
        private_den = (
            float(np.sum(signal[1:]) - signal[k + 1])
            + float(np.sum(error_by_stream))
            + equivalent_noise
        )

        common_each[k] = np.log2(
            1.0 + signal[0] / max(common_den, np.finfo(float).tiny)
        )
        private[k] = np.log2(
            1.0 + signal[k + 1]
            / max(private_den, np.finfo(float).tiny)
        )

    common = float(np.min(common_each))

    return {
        "common_rate_each_user": common_each,
        "private_rates": private,
        "common_rate": common,
        "sum_rate": common + float(np.sum(private)),
        "ris_noise_power_by_user_w": ris_noise_by_user,
    }


def radar_error_covariance(
    H_n: np.ndarray,
    phi: np.ndarray,
    H_br: np.ndarray,
    csi_error_w: float,
) -> np.ndarray:
    """Radar error covariance under independent i.i.d. link errors.

    Uses:
      E_r = E_m + E_n Phi H_BR
            + H_n Phi E_BR + E_n Phi E_BR.

    Returns an (M,M) covariance for the stated independent-error model.
    Validate this expansion against the paper's exact covariance convention.
    """
    H_n = _as_complex_array("H_n", H_n, 2)
    H_br = _as_complex_array("H_br", H_br, 2)
    phi = _as_complex_array("phi", phi, 1)
    sigma2 = _nonnegative_finite("csi_error_w", csi_error_w)

    M = H_br.shape[1]

    if H_br.shape[0] != phi.size or H_n.shape != (M, phi.size):
        raise ValueError("Expected H_n=(M,N), H_br=(N,M), phi=(N,).")

    weighted_H = H_br.conj().T @ (
        np.abs(phi)[:, None] ** 2 * H_br
    )
    HnPhi = H_n * phi[None, :]
    target_link_gain = float(np.linalg.norm(HnPhi, "fro") ** 2)

    product_error = (
        M * sigma2**2 * float(np.sum(np.abs(phi) ** 2))
    )

    covariance = (
        M * sigma2 * np.eye(M, dtype=complex)
        + M * sigma2 * weighted_H
        + (sigma2 * target_link_gain + product_error)
        * np.eye(M, dtype=complex)
    )

    return 0.5 * (covariance + covariance.conj().T)


def radar_sinr_paper(
    H_r: np.ndarray,
    H_n: np.ndarray,
    phi: np.ndarray,
    H_br: np.ndarray,
    P: np.ndarray,
    ris_noise_w: float,
    radar_noise_w: float,
    csi_error_w: float,
) -> float:
    """Radar SINR using the selected imperfect-CSI covariance model."""
    H_r = _as_complex_array("H_r", H_r, 2)
    H_n = _as_complex_array("H_n", H_n, 2)
    phi = _as_complex_array("phi", phi, 1)
    H_br = _as_complex_array("H_br", H_br, 2)
    P = _as_complex_array("P", P, 2)

    ris_noise_w = _nonnegative_finite("ris_noise_w", ris_noise_w)
    radar_noise_w = _nonnegative_finite("radar_noise_w", radar_noise_w)
    csi_error_w = _nonnegative_finite("csi_error_w", csi_error_w)

    M = H_r.shape[0]

    if H_r.shape != (M, M) or P.shape[0] != M:
        raise ValueError("Expected H_r=(M,M), P=(M,S).")
    if H_n.shape != (M, phi.size) or H_br.shape != (phi.size, M):
        raise ValueError("Expected H_n=(M,N), H_br=(N,M), phi=(N,).")

    radar_idx = P.shape[1] - 1
    Sigma_r = radar_error_covariance(
        H_n, phi, H_br, csi_error_w
    )

    error_power = sum(
        max(
            float(np.real(np.vdot(P[:, j], Sigma_r @ P[:, j]))),
            0.0,
        )
        for j in range(P.shape[1])
    )

    echo_power = np.array([
        float(np.linalg.norm(H_r @ P[:, j]) ** 2)
        for j in range(P.shape[1])
    ])

    HnPhi = H_n * phi[None, :]
    equivalent_noise = (
        ris_noise_w * float(np.linalg.norm(HnPhi, "fro") ** 2)
        + radar_noise_w
    )

    denominator = (
        float(np.sum(echo_power) - echo_power[radar_idx])
        + error_power + equivalent_noise
    )

    return float(
        echo_power[radar_idx] / max(denominator, np.finfo(float).tiny)
    )


def radar_sinr_proxy(
    target_channel: np.ndarray,
    precoders: np.ndarray,
    noise_w: float,
) -> float:
    """Diagnostic radar SINR proxy; not the paper's full radar model."""
    g = _as_complex_array("target_channel", target_channel, 1)
    P = _as_complex_array("precoders", precoders, 2)
    noise_w = _nonnegative_finite("noise_w", noise_w)

    if P.shape[0] != g.size or P.shape[1] < 1:
        raise ValueError(
            "target_channel length must equal the precoder row count."
        )

    echo = np.abs(g @ P) ** 2
    denominator = float(np.sum(echo[:-1]) + noise_w)

    return float(
        echo[-1] / max(denominator, np.finfo(float).tiny)
    )
