"""Radar echo channel used by the reproduction implementation.

The paper defines H_m and H_n through target reflection coefficients and steering
vectors, but does not give every target geometry/reflection parameter in Table I.
Those parameters are therefore exposed in SimulationConfig and are explicit
assumptions, not claimed paper-provided values.
"""
from __future__ import annotations
import numpy as np


def ula_vector(elements: int, angle_rad: float, spacing_wavelengths: float = 0.5) -> np.ndarray:
    n = np.arange(elements)
    return np.exp(1j * 2.0 * np.pi * spacing_wavelengths * n * np.sin(angle_rad))


def generate_radar_channels(cfg) -> tuple[np.ndarray, np.ndarray]:
    """Return H_m (M,M), H_n (M,N) using paper Eqs. (13)-(15).

    The target reflection coefficients and angles are assumptions in config.py.
    Steering vectors follow the paper's unnormalised ULA convention.
    """
    a_bs = ula_vector(cfg.M, cfg.target_angle_bs_rad, cfg.element_spacing_wavelengths)
    a_ris = ula_vector(cfg.N, cfg.target_angle_ris_rad, cfg.element_spacing_wavelengths)
    H_m = cfg.target_beta_m * np.outer(a_bs, np.conjugate(a_bs))
    H_n = cfg.target_beta_n * np.outer(a_bs, np.conjugate(a_ris))
    return H_m.astype(complex), H_n.astype(complex)


def radar_effective_channel(H_m: np.ndarray, H_n: np.ndarray, H_br: np.ndarray,
                            phi: np.ndarray) -> np.ndarray:
    """H_r = H_m + H_n diag(phi) H_BR, paper Eq. (11)."""
    return H_m + H_n @ (np.asarray(phi)[:, None] * H_br)
