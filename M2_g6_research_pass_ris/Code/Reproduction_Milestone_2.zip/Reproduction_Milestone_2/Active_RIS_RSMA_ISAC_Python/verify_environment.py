"""Check required imports and optionally test the installed MOSEK solver/license."""
import importlib.util
import sys

def main():
    for name in ('numpy','scipy','matplotlib','cvxpy'):
        if importlib.util.find_spec(name) is None:
            print(f'MISSING: {name}'); return 1
        print(f'OK: {name}')
    import cvxpy as cp
    print('Installed CVXPY solvers:', ', '.join(cp.installed_solvers()))
    if 'MOSEK' not in cp.installed_solvers():
        print('MOSEK not detected. Install `Mosek` in this Python environment and configure a license.')
        return 0
    x=cp.Variable()
    prob=cp.Problem(cp.Minimize(cp.square(x-2)), [x >= 0])
    try:
        prob.solve(solver=cp.MOSEK)
    except Exception as exc:
        print('MOSEK found but solve failed; check license/configuration.')
        print(f'{type(exc).__name__}: {exc}')
        return 2
    if prob.status not in ('optimal','optimal_inaccurate') or x.value is None or abs(float(x.value)-2)>1e-3:
        print(f'Solver check failed: status={prob.status}, x={x.value}'); return 3
    print(f'MOSEK smoke test PASSED: status={prob.status}, x={float(x.value):.6f}')
    return 0

if __name__=='__main__':
    sys.exit(main())
