"""Configuration and unit conversions for the Active RIS–RSMA–ISAC simulator."""
from dataclasses import dataclass
import numpy as np

def dbm_to_watt(power_dbm: float) -> float:
    """Convert dBm to watts: P[W] = 10**((P[dBm]-30)/10)."""
    return 10.0 ** ((float(power_dbm) - 30.0) / 10.0)

def watt_to_dbm(power_watt: float) -> float:
    """Convert positive watts to dBm."""
    if power_watt <= 0:
        return float('-inf')
    return 10.0 * np.log10(power_watt) + 30.0

@dataclass(frozen=True)
class SimulationConfig:
    M: int = 3
    K: int = 3
    N: int = 36
    bs_power_dbm: float = 35.0
    ris_power_dbm: float = 10.0
    vmax: float = 6.0
    receiver_noise_dbm: float = -80.0
    ris_noise_dbm: float = -80.0
    csi_error_dbm: float = -60.0
    rician_k: float = 3.0
    gamma_radar_threshold: float = 2.0
    tolerance: float = 1e-3
    # Explicit implementation assumptions; the paper does not specify these completely.
    wavelength_m: float = 0.1
    element_spacing_wavelengths: float = 0.5
    bs_ris_distance_m: float = 25.0
    bs_user_distance_m: float = 50.0
    ris_user_distance_m: float = 30.0
    # Target/radar geometry not fully specified by the paper; documented assumptions.
    target_angle_bs_rad: float = 0.25
    target_angle_ris_rad: float = -0.35
    target_beta_m: complex = 1.0 + 0.0j
    target_beta_n: complex = 1.0 + 0.0j
    radar_noise_dbm: float = -80.0
    cccp_max_iter: int = 15
    ris_sca_max_iter: int = 15
    ao_max_iter: int = 30
    randomization_trials: int = 30
    seed: int = 20261010

    @property
    def bs_power_w(self) -> float:
        return dbm_to_watt(self.bs_power_dbm)

    @property
    def ris_power_w(self) -> float:
        return dbm_to_watt(self.ris_power_dbm)

    @property
    def receiver_noise_w(self) -> float:
        return dbm_to_watt(self.receiver_noise_dbm)

    @property
    def ris_noise_w(self) -> float:
        return dbm_to_watt(self.ris_noise_dbm)

    @property
    def radar_noise_w(self) -> float:
        return dbm_to_watt(self.radar_noise_dbm)

    @property
    def csi_error_w(self) -> float:
        return dbm_to_watt(self.csi_error_dbm)

    def validate(self) -> None:
        if min(self.M, self.K, self.N) < 1:
            raise ValueError('M, K and N must all be positive integers.')
        if self.vmax <= 0 or self.tolerance <= 0:
            raise ValueError('vmax and tolerance must be positive.')
        if self.wavelength_m <= 0:
            raise ValueError('wavelength_m must be positive.')
